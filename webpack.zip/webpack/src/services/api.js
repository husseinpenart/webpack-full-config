export default class api {
    post(endpoint , data,options){
        console.log('Api Call')
    }
}