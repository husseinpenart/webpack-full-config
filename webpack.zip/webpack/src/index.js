// import api from './services/api'
// // import './assets/css/app.css'
// // import 'bootstrap/dist/css/bootstrap.rtl.css'
// import './pages/profile'
// const apiCall = new api()
// apiCall.post()
import React from "react";
import { render } from "react-dom";
const App = (props)=>{
    return <h1>
        Hello from React
    </h1>
}

render(<App/>,document.getElementById('root'))