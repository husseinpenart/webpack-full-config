import profileStyles from "../assets/css/profile.css";
const profilePage = () => {
  const wrapper = document.createElement("div");
  wrapper.setAttribute("class", "profile-wrapper");
  const title = document.createElement("h4");
  title.setAttribute("class", profileStyles.title);
  title.appendChild(document.createTextNode("profile page"));
  const body = document.createElement("div");
  body.setAttribute("class", profileStyles.body);
  body.appendChild(document.createTextNode("this is sample profile page"));
  wrapper.appendChild(title);
  wrapper.appendChild(body);
  return wrapper;
};

document.getElementById("#root").appendChild(profilePage());
